# Smartrecruit — código fuente

- `RosterReal.jsx`: toda la app (datos + interfaz). Es el archivo que se edita.
- `main.jsx`: arranca la app.
- `public/`: se copia tal cual al sitio. Incluye `index.html` (con PostHog, SEO e ícono), `assets/analytics.js` (PostHog + aviso de cookies), `robots.txt` y `sitemap.xml`.
- `analytics-src/entry.js`: código legible de la analítica (solo hace falta si se cambia).

Compilar: `npm install` y después `npm run build`. El resultado queda en `dist/`, que es la carpeta que se sube a Netlify.


## Funciones de servidor (Netlify)
- `netlify/functions/generate-email.mjs`: genera mails con Claude en `/api/generate-email`. Necesita la variable de entorno `ANTHROPIC_API_KEY` en Netlify (opcional: `ANTHROPIC_MODEL`).
- `netlify.toml`: comando de build, carpeta `dist` y carpeta de funciones.

## Mails: tipos, ganchos y registro (octubre 2026)
- `MAIL_KINDS`: los 7 tipos de mail (primer contacto, seguimiento, novedad, respuesta, post-llamada, oferta, cierre). `composeEmail` arma cada uno.
- Ganchos (`HOOK_LABELS`): dato propio, búsqueda publicada, staff compatriota, vacante proyectada, compatriotas en el plantel. La comparación de estadísticas contra el plantel se sacó de los mails (7/10/2026): solo pesa en el ranking. Un solo gancho por mail; los seguimientos usan uno que no se haya usado antes con ese coach.
- `rr_outreach_log[universidad].messages`: un registro por envío `{ at, kind, hook, lang, ai, stage, subject }`. `nextOutreachStep(entry)` dice qué toca (esperas de 10, 14 y 21 días; máximo 3 seguimientos).
- `rr_mail_facts`: datos que suma la atleta por universidad; se borran al usarlos en un envío.
- Analítica (solo con cookies aceptadas): eventos `mail_enviado` y `respuesta_registrada`, con tipo y gancho, sin texto del mail.

## Básquet D2: planteles (octubre 2026)
- `BBALL_D2_ROSTERS`: 258 planteles de básquet masculino NCAA D2 (RealGM, 21 de 23 conferencias), con posición, clase, ciudad y país de nacimiento. Formato `{ universidad: [temporada, filas] }`.
- Estadísticas 2025-26 (partidos, puntos y asistencias por partido) de 2.307 de los 4.200 jugadores: `datos-src/basquet_d2_stats_2025-26.csv` (`id_realgm,pj,ppg,apg`), cruzadas por id de jugador. Los ingresantes no tienen.
- 213 son de la temporada 2026-27 (la actual) y 40 de la 2025-26, porque RealGM todavía no había publicado su plantel nuevo. A esos el motor los "envejece": `activeRoster()` saca a los que ya terminaron su elegibilidad y `projectRosterForProfile()` estima las camadas que faltan.
- `datos-src/basquet_d2.py` regenera las constantes a partir de los CSV de una o más temporadas (ver el encabezado del script).
- `rosterPosMatch()`: en básquet agrupa posiciones en G / F / C.

## Contactos de coaches (7/10/2026)
- `BBALL_D2_COACHES_2026`: cuerpos técnicos 2026-27 de 24 programas de básquet D2, copiados de las páginas oficiales de staff.
- `coachContactFor()` descarta los contactos cuyo cargo dice ser de otro deporte. Había 172 contactos de básquet que en realidad eran entrenadores de fútbol (error de una carga anterior): ahora esos programas figuran sin mail hasta que se cargue el correcto.

### Auditoría de contactos (7/10/2026)
Pasada completa sobre `COACH_CONTACTS_BY_PROGRAM` (3.505 → 2.671 entradas). Script: `datos-src/contactos_auditoria.py <RosterReal.jsx>` (sobre datos limpios no cambia nada; correrlo con cada lote nuevo antes de publicar).
- **Lote de básquet del 2/10 eliminado (791 entradas: los 424 programas femeninos y 367 masculinos).** Era el staff de fútbol de cada universidad copiado como básquet. Básquet femenino queda sin contactos; masculino queda con 541 del lote bueno + los 24 cargados a mano.
- 50 contactos estaban en la universidad equivocada por nombre parecido (Cornell University ← Cornell College, Washington College ← University of Washington, etc.): 31 se reasignaron a la universidad correcta, 19 se descartaron (la correcta ya tenía contacto o no está en el catálogo).
- Descartados: 9 contactos de básquet cuyo "principal" no era coach (asistente ejecutiva, preparador físico), 3 con la rama cruzada, 1 de softball.
- Mails: 6 con formato inválido corregidos, 14 del principal quitados (eran de otra persona o de la institución), 178 marcados como mail del programa, 379 de asistentes quitados (repetían el del principal, eran compartidos o personales tipo gmail).
- Nombres: 65 limpiados (año de egreso, "Dr.", apodos, mayúsculas).
- `ROSTER_COACH_CONTACTS` (58 contactos viejos, uno por universidad): cada uno tiene ahora `sport` y `gender` y solo se usa para ese programa. Antes un "Head Coach" de hockey podía salir como contacto de otro deporte de la misma universidad.
- La ficha de universidad ("Coaches por programa") muestra exactamente lo que usa el armador de mails (`contactsForSchool` pasa por `coachContactFor`). Se quitó el aviso "Head Coach identificado por NCSA".
- Saludo: `coachLastName()` respeta apellidos con partícula ("Coach Van Dyke", "Coach da Luz") y saca sufijos (Jr., III).

## Calendario: desde cuándo puede contestar un coach (7/10/2026)
Son dos reglas distintas y la app ahora las separa:
- **Por año de la atleta** (`CONTACT_START`, `contactStartFor`, `contactStartText`): desde cuándo un coach puede escribirle, llamarla u ofrecerle algo. Se calcula con su año de ingreso (`getEntryYear`): en D1, 15/6 de dos años antes (básquet femenino 1/6); en D2 la comunicación es libre y las visitas oficiales y el contacto en persona arrancan el 15/6 previo al año junior (fuente: *NCAA Division II Coaches Off-Campus Recruiting Guide 2026-27*). Se muestra en la página Calendario ("Tu caso"), en Inicio y en el aviso de cada mail.
- **Por fecha** (`SPORT_CALENDARS[...].events`): períodos de contacto, evaluación, silencioso y muerto. Solo limitan el contacto en persona, las visitas y las evaluaciones; no los mails.
- Corregido: para las mujeres en fútbol y básquet el armador de mails no encontraba el calendario (buscaba "Soccer (W)" y la clave es "Soccer (F)"); `contactWindowNote` decía que el coach "puede responderte recién" al abrir el próximo período de contacto; con dos períodos activos a la vez se tomaba el primero de la lista y no el más corto (un período muerto dentro de uno de contacto no se detectaba).
- "2° año de secundaria" se reemplazó por "año sophomore (10.º grado de EE.UU.: el antepenúltimo año de tu secundaria)".
- Básquet masculino D1 contrastado con el PDF oficial de la NCAA (actualizado el 30/7/2026): coincide; se agregaron las ventanas de evaluación y el período silencioso del 19 al 25/7/2027.
- Contrastados después con los PDF oficiales (todos actualizados el 30/7/2026): **vóley** (coincide; el período silencioso 1/5-3/6 es correcto y NCSA lo omite), **básquet femenino** (shutdown 3-9/5 correcto; se agregaron los días muertos del 22/4, 26/4 y 17/5 y las ventanas de evaluación), **atletismo** (coincide; se agregaron los dos períodos de contacto).
- El "recruiting shutdown" es el único período en que el coach tampoco puede escribir ni llamar: el aviso del mail lo dice aparte.
- Con las páginas por deporte de NCSA (7/10/2026): **gimnasia** pasa a la regla general de primer contacto (15/6 al terminar sophomore, visitas desde el 1/8; antes decía 1/9 del año junior); **hockey** coincide con lo cargado (silencioso 20-23/12, shutdown 24/12-1/1); D3 suma las visitas oficiales desde el 1/1 del año junior.
- **Pendiente** (hace falta el PDF oficial "Division I Other Sports"): fútbol femenino (período muerto desde el 15/12 según NCSA, 16/12 en la app), si hockey tiene además el período muerto del 9-12/11, y los períodos de gimnasia. Atletismo: la fecha de primer contacto (1/9 del año junior) sigue sin contrastar.
